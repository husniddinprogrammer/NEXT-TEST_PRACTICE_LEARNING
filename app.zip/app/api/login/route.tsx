import { cookies } from "next/headers";

export async function POST(req: Request) {
  const { username, password } = await req.json();

  
  if (username === "admin@gmail.com" && password === "123") {
    (await cookies()).set("token", "my-secret-token");

    return Response.json({ message: "Login success" });
  }

  return new Response("Invalid credentials", { status: 401 });
}